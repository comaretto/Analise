export const estilo = {
  container: {
    backgroundColor:'#aff',
    flex:1
  },
  texto:{
    color:"#effdd",
    fontSize: 40
  },
  bola:{
    width:100,
    height:100,
    borderRadius:50,
    marginTop:10,
    alignItems:'center'
  },
  bgAzul:{
    backgroundColor:'#00f'
  },
  bgAmarelo:{
     backgroundColor:'#FFD200'
  },
  button:{
    alignItems:'center',
    backgroundColor: '#DDDDDD',
    padding:10
  },
  btnText:{
    alignSelf:'center',
    fontSize:25,
    color:'#fff',
    padding:10
  }
}