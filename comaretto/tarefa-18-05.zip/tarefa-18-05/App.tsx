import React, { useState } from 'react';
import { View, Text, Button, TouchableOpacity } from 'react-native'
import { estilo } from './estilo';

const App = () => {
  return(
   <View style={estilo.container}>
    <Text style={estilo.texto}>Aula de Programção Mobile</Text>
    <Text style={{textAlign: 'center'}}>Estilização</Text>
    <View style={[estilo.bola, estilo.bgAzul, {alignSelf:'center'}]}></View>
    <View style={[estilo.bola, estilo.bgAmarelo]}></View>
    <View style={{width: 200, alignSelf: 'center'}}>
      <Button
      title="logar"
      color='#aaa'
      style={{borderRadius: 30}}
      />
  </View>
  <View style={{ width: 200, alignSelf: 'center' }}>
     <TouchableOpacity style={estilo.bgAzul}>
      <Text style={ estilo.btnText}> Clique Aqui</Text>
     </TouchableOpacity>
    </View>
  </View>
  );
};
export default App;
    








