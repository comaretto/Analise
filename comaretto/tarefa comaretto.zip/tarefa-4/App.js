import React from "react";
import { View, Text, Image, Button} from 'react-native';

const App = () =>{

  return(
    <View style={styles.container}>
    <Text style={styles.texto}>VITORINHA </Text>
    <View style={styles.quadrado1}></View>
    <View style={styles.quadrado2}></View>
    <View style={styles.quadrado3}></View>
    <View style={styles.quadrado4}></View>
    </View>
  )
}

export default App;
const styles = {
  container:{
    backgroundColor: 'white',
    flex: 1,
  },
  texto:{
    color:'black',
    fontSize:45
   
  },
  
  quadrado1:{
    backgroundColor:'pink',
    width:60,
    height:60,
    borderWidth:6,
    marginTop:5,
    borderColor:'black'
  
  },
   quadrado2:{
    backgroundColor:'green',
    width:90,
    height:90,
    borderWidth:4,
    marginTop:7,
    borderColor:'pink'
  
  },
   quadrado3:{
    backgroundColor:'brown',
    width:150,
    height:150,
    borderWidth:9,
    marginTop:9,
    borderColor:'red'
  
  },
   quadrado4:{
    backgroundColor:'purple',
    width:72,
    height:72,
    borderWidth:5,
    marginTop:5,
    borderColor:'orange'
  
  },


}