export const estilo = {
  scroll:{
    backgroundColor: '#2D2C2C',
    paddingHorizontal: 15,
    paddingTop: 50
  },
  container:{
    alignItems: 'center'
  },
  logo:{
    width: 250,
    height: 250
  },
  inputArea:{
    paddingTop: 20,
    width: '100%',

  },
  textoLabel:{
    color: '#FFFFFF',
    fontSize: 25,
    fontWeight: 'bold',
    marginBottom: 10
  },
  textoInput:{
    borderWidth: 2,
    borderColor: '#FFFFFF',
    fontSize: 15,
    padding:15,
    backgroundColor:'#FFFFFF',
    marginBottom:10

  },
  botao:{
    backgroundColor: '#E10000',
    width: '50%',
    padding: 15
  },
  txtbotao:{
    textAlign: 'center',
    color:'#fff',
    fontSize: 30
  },
  entrada:{
    flexDirection: 'row',
    marginTop: 40
  },
  txtentrada: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#777'
  },
  txtbtnentrada: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#416287',
    marginLeft: 5
  },
  rodape:{
    marginVertical: 30
  },
  txtrodape: {
    fontSize: 16,
    color: '#999'
  }
}