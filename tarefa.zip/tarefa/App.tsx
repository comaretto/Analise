import React, {useState} from 'react';
import {ScrollView, View, Text, TextInput, TouchableOpacity, Image} from 'react-native';
import {estilo} from './estilos';

const App = () => {
  const[email, setEmail] = useState('');
  const[senha, setSenha] = useState('');

  const pegaDados = () => {
    alert("Email: "+email);
    alert("Senha: " + senha);
  }

  const esqueciSenha = () => {}

  const cadastre = () => {}
 
  return(
    <ScrollView style={estilo.scroll}>
      <View style={estilo.container}>
        <Image
          source={require('./assets/comaretto.png')}
          style={estilo.logo}
        />
       
        <View style={estilo.inputArea}>
          <Text style={estilo.textoLabel}>Usuário:</Text>
          <TextInput
            value={email}
            onChangeText={t => setEmail(t)}
            autoCapitalize="none"
            keyboardType='email-address'
            style={estilo.textoInput}
          />
        </View>

        <View style={estilo.inputArea}>
          <Text style={estilo.textoLabel}>Senha:</Text>
          <TextInput
            placeholder='Insira sua senha'
            placeholderTextColor = "white"
            style={estilo.textoInput}
            secureTextEntry
            autoCapitalize="none"
            value={senha}
            onChangeText={t => setSenha(t)}
          />
        </View>

        <TouchableOpacity style={estilo.botao} onPress={pegaDados}>
          <Text style={estilo.txtbotao}>Entrar</Text>
        </TouchableOpacity>

      </View>
     
    </ScrollView>
  );

}
export default App;